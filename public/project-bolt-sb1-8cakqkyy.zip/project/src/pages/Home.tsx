import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Github, Linkedin, Mail, ArrowRight } from 'lucide-react';

const Home = () => {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
        <div className="absolute inset-0 bg-black/30"></div>
      </div>
      
      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="relative z-10 text-center text-white max-w-4xl mx-auto px-6">
        <div className="mb-8">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up">
            Hi, I'm <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Bibek</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 animate-fade-in-up animation-delay-200">
            Full Stack Developer & Software Engineer
          </p>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12 animate-fade-in-up animation-delay-400">
            I create exceptional digital experiences through clean code, innovative solutions, and user-centered design.
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 animate-fade-in-up animation-delay-600">
          <Link 
            to="/projects"
            className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center"
          >
            View My Work
            <ArrowRight size={20} className="ml-2" />
          </Link>
          <Link 
            to="/contact"
            className="px-8 py-3 border-2 border-white/30 text-white rounded-lg hover:bg-white/10 transition-all duration-300 transform hover:scale-105 flex items-center justify-center"
          >
            Get In Touch
          </Link>
        </div>

        {/* Social Links */}
        <div className="flex justify-center space-x-6 mb-16 animate-fade-in-up animation-delay-800">
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" 
             className="p-3 border border-white/30 rounded-full hover:bg-white/10 transition-all duration-300 transform hover:scale-110">
            <Github size={24} />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
             className="p-3 border border-white/30 rounded-full hover:bg-white/10 transition-all duration-300 transform hover:scale-110">
            <Linkedin size={24} />
          </a>
          <a href="mailto:hello@bibeksabat.com"
             className="p-3 border border-white/30 rounded-full hover:bg-white/10 transition-all duration-300 transform hover:scale-110">
            <Mail size={24} />
          </a>
        </div>

        {/* Quick Navigation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
          <Link 
            to="/about"
            className="p-4 bg-gray-800/30 backdrop-blur-sm rounded-lg border border-gray-700/50 hover:bg-gray-800/50 transition-all duration-300 transform hover:scale-105"
          >
            <h3 className="text-white font-semibold mb-1">About</h3>
            <p className="text-gray-400 text-sm">Learn more about me</p>
          </Link>
          <Link 
            to="/skills"
            className="p-4 bg-gray-800/30 backdrop-blur-sm rounded-lg border border-gray-700/50 hover:bg-gray-800/50 transition-all duration-300 transform hover:scale-105"
          >
            <h3 className="text-white font-semibold mb-1">Skills</h3>
            <p className="text-gray-400 text-sm">My expertise</p>
          </Link>
          <Link 
            to="/projects"
            className="p-4 bg-gray-800/30 backdrop-blur-sm rounded-lg border border-gray-700/50 hover:bg-gray-800/50 transition-all duration-300 transform hover:scale-105"
          >
            <h3 className="text-white font-semibold mb-1">Projects</h3>
            <p className="text-gray-400 text-sm">My work</p>
          </Link>
          <Link 
            to="/experience"
            className="p-4 bg-gray-800/30 backdrop-blur-sm rounded-lg border border-gray-700/50 hover:bg-gray-800/50 transition-all duration-300 transform hover:scale-105"
          >
            <h3 className="text-white font-semibold mb-1">Experience</h3>
            <p className="text-gray-400 text-sm">My journey</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;