import React from 'react';
import { Code, Database, Cloud, Smartphone, Globe, Zap } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: 'Frontend',
      icon: <Globe className="text-blue-400" size={24} />,
      skills: [
        { name: 'React', level: 95 },
        { name: 'TypeScript', level: 90 },
        { name: 'Next.js', level: 88 },
        { name: 'Tailwind CSS', level: 92 },
        { name: 'Vue.js', level: 85 },
      ]
    },
    {
      title: 'Backend',
      icon: <Code className="text-green-400" size={24} />,
      skills: [
        { name: 'Node.js', level: 92 },
        { name: 'Python', level: 88 },
        { name: 'GraphQL', level: 85 },
        { name: 'REST APIs', level: 95 },
        { name: 'Express.js', level: 90 },
      ]
    },
    {
      title: 'Database',
      icon: <Database className="text-purple-400" size={24} />,
      skills: [
        { name: 'PostgreSQL', level: 88 },
        { name: 'MongoDB', level: 85 },
        { name: 'Redis', level: 80 },
        { name: 'Supabase', level: 90 },
        { name: 'Prisma', level: 87 },
      ]
    },
    {
      title: 'Cloud & DevOps',
      icon: <Cloud className="text-cyan-400" size={24} />,
      skills: [
        { name: 'AWS', level: 85 },
        { name: 'Docker', level: 88 },
        { name: 'Kubernetes', level: 75 },
        { name: 'CI/CD', level: 82 },
        { name: 'Vercel', level: 92 },
      ]
    },
    {
      title: 'Mobile',
      icon: <Smartphone className="text-orange-400" size={24} />,
      skills: [
        { name: 'React Native', level: 85 },
        { name: 'Flutter', level: 78 },
        { name: 'iOS (Swift)', level: 75 },
        { name: 'Android', level: 80 },
        { name: 'Expo', level: 88 },
      ]
    },
    {
      title: 'Tools & Others',
      icon: <Zap className="text-yellow-400" size={24} />,
      skills: [
        { name: 'Git', level: 95 },
        { name: 'Figma', level: 85 },
        { name: 'Jest', level: 82 },
        { name: 'Webpack', level: 80 },
        { name: 'Vite', level: 90 },
      ]
    },
  ];

  return (
    <div className="py-20 bg-gray-800 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Skills & <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Expertise</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Technologies and tools I use to bring ideas to life
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div 
              key={index}
              className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 hover:bg-gray-900/70 transition-all duration-300"
            >
              <div className="flex items-center mb-6">
                {category.icon}
                <h2 className="text-xl font-bold text-white ml-3">{category.title}</h2>
              </div>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-300 font-medium">{skill.name}</span>
                      <span className="text-gray-400 text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-1000 ease-out"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;