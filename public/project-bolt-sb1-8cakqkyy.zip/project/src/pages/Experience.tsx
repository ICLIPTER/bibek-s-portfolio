import React from 'react';
import { Briefcase, Calendar, MapPin, Award } from 'lucide-react';

const Experience = () => {
  const experiences = [
    {
      title: 'Senior Full Stack Developer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      duration: '2022 - Present',
      type: 'Full-time',
      description: 'Lead development of cloud-native applications serving 100k+ users. Architected microservices infrastructure and mentored junior developers.',
      achievements: [
        'Reduced application load time by 60% through optimization',
        'Led team of 5 developers on major product releases',
        'Implemented CI/CD pipeline reducing deployment time by 80%'
      ],
      technologies: ['React', 'Node.js', 'AWS', 'Docker', 'TypeScript']
    },
    {
      title: 'Full Stack Developer',
      company: 'Innovation Labs',
      location: 'Remote',
      duration: '2020 - 2022',
      type: 'Full-time',
      description: 'Developed and maintained multiple client projects ranging from e-commerce platforms to data visualization dashboards.',
      achievements: [
        'Delivered 15+ successful projects on time and within budget',
        'Improved client satisfaction scores by 40%',
        'Introduced automated testing practices to the team'
      ],
      technologies: ['Vue.js', 'Python', 'PostgreSQL', 'GCP', 'Django']
    },
    {
      title: 'Frontend Developer',
      company: 'StartupXYZ',
      location: 'New York, NY',
      duration: '2019 - 2020',
      type: 'Full-time',
      description: 'Built responsive web applications and collaborated with design team to create pixel-perfect user interfaces.',
      achievements: [
        'Increased user engagement by 35% through UX improvements',
        'Built reusable component library used across 5+ projects',
        'Optimized SEO resulting in 50% increase in organic traffic'
      ],
      technologies: ['React', 'JavaScript', 'SASS', 'Webpack', 'Jest']
    },
    {
      title: 'Junior Web Developer',
      company: 'WebDev Agency',
      location: 'Austin, TX',
      duration: '2018 - 2019',
      type: 'Full-time',
      description: 'Started my professional journey building websites for small businesses and learning industry best practices.',
      achievements: [
        'Completed 20+ client websites with 5-star reviews',
        'Learned modern development frameworks and tools',
        'Contributed to open-source projects'
      ],
      technologies: ['HTML', 'CSS', 'JavaScript', 'PHP', 'WordPress']
    }
  ];

  const education = [
    {
      degree: 'Bachelor of Science in Computer Science',
      school: 'University of Technology',
      location: 'California, USA',
      duration: '2014 - 2018',
      gpa: '3.8/4.0',
      achievements: [
        'Magna Cum Laude',
        'Dean\'s List for 6 semesters',
        'President of Computer Science Club'
      ]
    }
  ];

  const certifications = [
    { name: 'AWS Certified Solutions Architect', year: '2023' },
    { name: 'Google Cloud Professional Developer', year: '2022' },
    { name: 'MongoDB Certified Developer', year: '2021' },
    { name: 'React Native Certified Developer', year: '2020' }
  ];

  return (
    <div className="py-20 bg-gray-800 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Experience & <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Education</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            My professional journey and continuous learning path
          </p>
        </div>

        {/* Work Experience */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-8 flex items-center">
            <Briefcase className="mr-3 text-blue-400" size={24} />
            Work Experience
          </h2>
          
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <div 
                key={index}
                className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700/50 hover:bg-gray-900/70 transition-all duration-300"
              >
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">{exp.title}</h3>
                    <p className="text-blue-400 font-semibold mb-2">{exp.company}</p>
                    <div className="flex flex-wrap items-center gap-4 text-gray-400 text-sm mb-4">
                      <span className="flex items-center">
                        <Calendar size={14} className="mr-1" />
                        {exp.duration}
                      </span>
                      <span className="flex items-center">
                        <MapPin size={14} className="mr-1" />
                        {exp.location}
                      </span>
                      <span className="px-2 py-1 bg-gray-700/50 rounded text-xs">
                        {exp.type}
                      </span>
                    </div>
                  </div>
                </div>
                
                <p className="text-gray-300 mb-4 leading-relaxed">{exp.description}</p>
                
                <div className="mb-4">
                  <h4 className="text-white font-semibold mb-2 flex items-center">
                    <Award size={16} className="mr-2 text-yellow-400" />
                    Key Achievements
                  </h4>
                  <ul className="space-y-1">
                    {exp.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-gray-300 text-sm flex items-start">
                        <span className="w-2 h-2 bg-blue-400 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {exp.technologies.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-3 py-1 bg-gray-700/50 text-gray-300 text-sm rounded-full border border-gray-600/50"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Education & Certifications */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Education */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Education</h2>
            {education.map((edu, index) => (
              <div 
                key={index}
                className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50"
              >
                <h3 className="text-lg font-bold text-white mb-2">{edu.degree}</h3>
                <p className="text-blue-400 font-semibold mb-2">{edu.school}</p>
                <div className="flex flex-wrap items-center gap-4 text-gray-400 text-sm mb-4">
                  <span className="flex items-center">
                    <Calendar size={14} className="mr-1" />
                    {edu.duration}
                  </span>
                  <span className="flex items-center">
                    <MapPin size={14} className="mr-1" />
                    {edu.location}
                  </span>
                  <span className="px-2 py-1 bg-gray-700/50 rounded text-xs">
                    GPA: {edu.gpa}
                  </span>
                </div>
                <ul className="space-y-1">
                  {edu.achievements.map((achievement, achIndex) => (
                    <li key={achIndex} className="text-gray-300 text-sm flex items-start">
                      <span className="w-2 h-2 bg-purple-400 rounded-full mr-3 mt-2 flex-shrink-0"></span>
                      {achievement}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Certifications */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Certifications</h2>
            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <div 
                  key={index}
                  className="bg-gray-900/50 backdrop-blur-sm rounded-xl p-4 border border-gray-700/50 flex items-center justify-between hover:bg-gray-900/70 transition-all duration-300"
                >
                  <span className="text-white font-medium">{cert.name}</span>
                  <span className="text-gray-400 text-sm">{cert.year}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Experience;