import React from 'react';
import { Heart, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col items-center">
          {/* Back to Top Button */}
          <button
            onClick={scrollToTop}
            className="mb-6 p-3 bg-gray-800 hover:bg-gray-700 text-white rounded-full transition-all duration-300 transform hover:scale-110"
            aria-label="Back to top"
          >
            <ArrowUp size={20} />
          </button>

          {/* Copyright */}
          <div className="text-center">
            <p className="text-gray-400 flex items-center justify-center">
              © 2024 Bibek Sabat. Made with 
              <Heart className="text-red-400 mx-2" size={16} fill="currentColor" />
              and lots of coffee
            </p>
            <p className="text-gray-500 text-sm mt-2">
              Built with React, TypeScript, and Tailwind CSS
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;