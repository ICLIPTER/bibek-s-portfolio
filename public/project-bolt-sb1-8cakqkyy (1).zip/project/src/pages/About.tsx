import React from 'react';
import { User, Award, Coffee, Heart } from 'lucide-react';

const About = () => {
  const stats = [
    { icon: <Award className="text-blue-400" size={24} />, value: '5+', label: 'Years Experience' },
    { icon: <User className="text-purple-400" size={24} />, value: '50+', label: 'Projects Completed' },
    { icon: <Coffee className="text-yellow-400" size={24} />, value: '1000+', label: 'Cups of Coffee' },
    { icon: <Heart className="text-red-400" size={24} />, value: '∞', label: 'Passion for Code' },
  ];

  return (
    <div className="py-20 bg-gray-900 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            About <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Me</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Passionate developer with a love for creating innovative solutions
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">My Journey</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                I'm a passionate full-stack developer with over 5 years of experience building 
                web applications and digital solutions. My journey began with a curiosity about 
                how things work on the web, which evolved into a deep love for creating 
                meaningful user experiences.
              </p>
              <p className="text-gray-300 leading-relaxed mb-4">
                I specialize in modern JavaScript frameworks, cloud technologies, and 
                scalable architecture design. I believe in writing clean, maintainable code 
                and following best practices to deliver high-quality solutions.
              </p>
              <p className="text-gray-300 leading-relaxed">
                When I'm not coding, you'll find me exploring new technologies, contributing 
                to open source projects, or sharing knowledge with the developer community.
              </p>
            </div>

            <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-8 border border-gray-700/50">
              <h2 className="text-2xl font-bold text-white mb-4">What I Do</h2>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-blue-400 rounded-full mr-3"></span>
                  Full-stack web application development
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-purple-400 rounded-full mr-3"></span>
                  API design and microservices architecture
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-teal-400 rounded-full mr-3"></span>
                  Cloud infrastructure and DevOps
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-orange-400 rounded-full mr-3"></span>
                  Mobile app development
                </li>
              </ul>
            </div>
          </div>

          {/* Right Content - Stats */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700/50 text-center hover:bg-gray-800/70 transition-all duration-300 transform hover:scale-105"
              >
                <div className="flex justify-center mb-4">
                  {stat.icon}
                </div>
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;