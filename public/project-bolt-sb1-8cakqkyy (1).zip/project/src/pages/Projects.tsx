import React from 'react';
import { ExternalLink, Github, Laptop, Smartphone, Globe } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: 'E-Commerce Platform',
      description: 'A full-stack e-commerce solution with React, Node.js, and Stripe integration. Features real-time inventory, user authentication, and admin dashboard.',
      image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['React', 'Node.js', 'PostgreSQL', 'Stripe', 'AWS'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'web',
      featured: true
    },
    {
      title: 'Task Management App',
      description: 'Mobile-first task management application with real-time collaboration, built with React Native and Firebase.',
      image: 'https://images.pexels.com/photos/3183153/pexels-photo-3183153.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['React Native', 'Firebase', 'Redux', 'TypeScript'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'mobile',
      featured: true
    },
    {
      title: 'Analytics Dashboard',
      description: 'Real-time analytics dashboard with interactive charts and data visualization for business intelligence.',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Vue.js', 'D3.js', 'Python', 'FastAPI', 'Docker'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'web',
      featured: true
    },
    {
      title: 'Social Media API',
      description: 'RESTful API for social media platform with user management, posts, and real-time messaging capabilities.',
      image: 'https://images.pexels.com/photos/267389/pexels-photo-267389.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Node.js', 'Express', 'MongoDB', 'Socket.io', 'JWT'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'backend',
      featured: false
    },
    {
      title: 'Portfolio Website',
      description: 'Responsive portfolio website built with Next.js, featuring animations and optimized performance.',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Next.js', 'Tailwind CSS', 'Framer Motion', 'Vercel'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'web',
      featured: false
    },
    {
      title: 'Weather App',
      description: 'Cross-platform weather application with location services and detailed forecasts.',
      image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=800',
      tags: ['Flutter', 'Dart', 'OpenWeather API', 'Google Maps'],
      demoUrl: '#',
      githubUrl: '#',
      type: 'mobile',
      featured: false
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'web':
        return <Globe size={16} className="text-blue-400" />;
      case 'mobile':
        return <Smartphone size={16} className="text-green-400" />;
      case 'backend':
        return <Laptop size={16} className="text-purple-400" />;
      default:
        return <Globe size={16} className="text-blue-400" />;
    }
  };

  const featuredProjects = projects.filter(project => project.featured);
  const otherProjects = projects.filter(project => !project.featured);

  return (
    <div className="py-20 bg-gray-900 min-h-screen">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Featured <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Projects</span>
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            A showcase of my recent work and creative projects
          </p>
        </div>

        {/* Featured Projects */}
        <div className="grid lg:grid-cols-1 gap-8 mb-16">
          {featuredProjects.map((project, index) => (
            <div 
              key={index}
              className="bg-gray-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-gray-700/50 hover:bg-gray-800/70 transition-all duration-300 group"
            >
              <div className="lg:flex">
                <div className="lg:w-1/2">
                  <div className="relative overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-64 lg:h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent"></div>
                  </div>
                </div>
                <div className="lg:w-1/2 p-8">
                  <div className="flex items-center mb-4">
                    {getTypeIcon(project.type)}
                    <span className="text-gray-400 text-sm ml-2 uppercase tracking-wide">
                      {project.type} Project
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-4">{project.title}</h2>
                  <p className="text-gray-300 mb-6 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-6">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="px-3 py-1 bg-gray-700/50 text-gray-300 text-sm rounded-full border border-gray-600/50"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex space-x-4">
                    <a 
                      href={project.demoUrl}
                      className="flex items-center px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all duration-300 transform hover:scale-105"
                    >
                      <ExternalLink size={16} className="mr-2" />
                      Live Demo
                    </a>
                    <a 
                      href={project.githubUrl}
                      className="flex items-center px-4 py-2 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-all duration-300 transform hover:scale-105"
                    >
                      <Github size={16} className="mr-2" />
                      Code
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Other Projects Grid */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Other Projects</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {otherProjects.map((project, index) => (
              <div 
                key={index}
                className="bg-gray-800/50 backdrop-blur-sm rounded-xl overflow-hidden border border-gray-700/50 hover:bg-gray-800/70 transition-all duration-300 group transform hover:scale-105"
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent"></div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center mb-3">
                    {getTypeIcon(project.type)}
                    <span className="text-gray-400 text-xs ml-2 uppercase tracking-wide">
                      {project.type}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{project.title}</h3>
                  <p className="text-gray-300 text-sm mb-4 leading-relaxed">{project.description}</p>
                  
                  <div className="flex flex-wrap gap-1 mb-4">
                    {project.tags.slice(0, 3).map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="px-2 py-1 bg-gray-700/50 text-gray-300 text-xs rounded border border-gray-600/50"
                      >
                        {tag}
                      </span>
                    ))}
                    {project.tags.length > 3 && (
                      <span className="px-2 py-1 text-gray-400 text-xs">
                        +{project.tags.length - 3} more
                      </span>
                    )}
                  </div>

                  <div className="flex space-x-3">
                    <a 
                      href={project.demoUrl}
                      className="flex items-center text-blue-400 hover:text-blue-300 transition-colors duration-200 text-sm"
                    >
                      <ExternalLink size={14} className="mr-1" />
                      Demo
                    </a>
                    <a 
                      href={project.githubUrl}
                      className="flex items-center text-gray-400 hover:text-gray-300 transition-colors duration-200 text-sm"
                    >
                      <Github size={14} className="mr-1" />
                      Code
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Projects;